{{--@php--}}
{{-- $banners=app()->make(\App\Repositories\BannerRepository::class)->getBanners();--}}
{{--@endphp--}}
{{--<div class="category-box container">--}}

{{--@foreach($banners??[] as $banner)--}}
{{--   @include('site.home.banner-widget')--}}
{{--@endforeach--}}

{{--</div>--}}


