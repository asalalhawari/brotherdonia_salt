<div class="modal fade" id="imageModalId" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true" style="    z-index: 9999;">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-sm close"  data-dismiss="modal"
                        onclick="javascript:$('#imageModalId').modal('hide')" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="data-container">
                <div class="justify-content-center">
                    <img src="" alt="Product" class="img-center"  >
                </div>
            </div>

        </div>
    </div>
</div>
