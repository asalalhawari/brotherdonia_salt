<!DOCTYPE html>
<html>
<body>

{!! $entity->Replay !!}

</BR>

@langucw('thank you for reaching out to us')

</BR>

{{config('app.name')}}

</body>
</html>
