{{-- <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 2.0
    </div>
    <strong>Copyright &copy; {{ now()->format('Y') }} <a
            href="{{ config('app.url') }}">{{ config('app.name') }}</a>.</strong> All rights reserved.
</footer> --}}
