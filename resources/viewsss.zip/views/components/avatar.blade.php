<img width="50%" height="50%" src="{{asset($entity->avatar('small'))}}">
