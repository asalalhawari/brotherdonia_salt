<?php

namespace App\Filament\Resources\OrderAcceptResource\Pages;

use App\Filament\Resources\OrderAcceptResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewUser extends ViewRecord
{
    protected static string $resource = OrderAcceptResource::class;
}
