<?php

namespace App\Filament\Resources\OrderInvoicedResource\Pages;

use App\Filament\Resources\OrderInvoicedResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOrderInvoiced extends CreateRecord
{
    protected static string $resource = OrderInvoicedResource::class;
}
