<?php

namespace App\Filament\Resources\ConditionalDeliveryResource\Pages;

use App\Filament\Resources\ConditionalDeliveryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateConditionalDelivery extends CreateRecord
{
    protected static string $resource = ConditionalDeliveryResource::class;
}
